<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCACpnp7KaVFiuYEfwaxiKS7OCgw0mQqcA&libraries=places&callback=initMap">
</script>